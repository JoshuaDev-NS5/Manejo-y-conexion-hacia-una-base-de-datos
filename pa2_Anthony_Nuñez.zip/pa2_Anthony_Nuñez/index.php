<?php
    require_once("./controladores/funciones.php");
    $bd=conectar_base_de_datos('localhost','cine_isil','root','');
    $titulo='';
    $calificacion='';
    $premios='';
    $fecha_de_cracion='';
    $duracion='';
    $genero='';
    $errores=[];
    if($_POST){
        //var_dump($_POST);
       // exit;
        $titulo=$_POST["titulo"];
        $calificacion=$_POST["calificacion"];
        $premios=$_POST["premios"];
        $fecha_de_cracion=$_POST ["fechaCreacion"];
        $duracion=$_POST["duracion"];
        $genero=$_POST["genero"];
        $errores=validadar_datos($_POST);
        if(count($errores)===0){
            /*var_dump($_POST);*/
            conectar_a_tabla_movies($bd,'movies', $_POST);//agrega datos a la database
        }

        
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/style.css">
    <title>Cine_Isil</title>
</head>

<body>
    <div class="container-fluid px-0" id="inicio">
        <nav class="navbar navbar-expand-lg bg-body-tertiary py-0 sticky-top  ">
            <div class="container-fluid">
                <a class="navbar-brand" href="#"><img class="logo" src="./img/Logo-ISIL.webp" alt=""></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav gap-3">
                        <li class="nav-item estilo">
                            <a class="nav-link " aria-current="page" href="#Estrenos">Estrenos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#Cartelera">Cartelera</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#Agregar">Agregar Pelicula</a>
                        </li>

                    </ul>
                </div>
            </div>
        </nav>
        <div class="Estrenos" id="Estrenos">
            <div id="carouselExampleCaptions" class="carousel slide">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
                        aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                        aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                        aria-label="Slide 3"></button>
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="3"
                        aria-label="Slide 4"></button>
                </div>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="./img/TRON-Ares-motos (1).webp" class="d-block w-100" alt="...">

                    </div>
                    <div class="carousel-item">
                        <img src="./img/el-conjuro-4-ultimos-ritos-estreno-1756996715.jpg" class="d-block w-100"
                            alt="...">

                    </div>
                    <div class="carousel-item">
                        <img src="./img/Oppenheimer.jpg" class="d-block w-100" alt="...">

                    </div>
                    <div class="carousel-item">
                        <img src="./img/thunderboldts.jpg" class="d-block w-100" alt="...">

                    </div>

                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
        <section >
            <h2 class="text-center py-2">CARTELERA</h2>
            <div class="row" id="Cartelera">
            </div>
        </section>
        
        <div class="row" id="Agregar">
            <h2 class="text-center separador py-3">AGREGAR PELICULAS</h2>
            <form action="" method="post" class="col-10 col-md-6 col-lg-4 m-auto my-4">
                <?php if(count($errores) > 0):?> 
                                <ul class="alert alert-danger" style="list-style: disc; padding-left: 40px;">
                                    <?php
                                    foreach ($errores as $index =>  $error) :?>
                                        <li class><?=$error?></li>      
                                    <?php endforeach;?>
                                </ul>
                <?php endif?>
                <div class="mb-3">
                    <label for="titulo" class="form-label">Titulo</label>
                    <input type="text" name="titulo" class="form-control" id="titulo" value="<?=$titulo?>" >
                </div>
                <div class="mb-3">
                    <label for="calificacion" class="form-label">Calificacion</label>
                    <input type="number" name="calificacion" class="form-control" id="calificacion" value="<?=$calificacion?>">
                </div>
                <div class="mb-3">
                    <label for="premios" class="form-label">Premios</label>
                    <input type="number" name="premios" class="form-control" id="premios" value="<?=$premios?>" >
                </div>
                <div class="mb-3">
                    <label for="fechaCreacion" class="form-label">Fecha de Creacion </label>
                    <input type="date" name="fechaCreacion" class="form-control" id="fechaCreacion" value="<?=$fecha_de_cracion?>" >
                </div>
                <div class="mb-3">
                    <label for="duracion" class="form-label">Duracion</label>
                    <input type="number" name="duracion" class="form-control" id="duracion" value="<?=$duracion?>" >
                </div>
                <div class="mb-3">
                    <label for="genero" class="form-label">Genero</label>
                    <input type="text" name="genero" class="form-control" id="genero" value="<?=$genero?>" >
                </div>
                <button type="submit" class="btn btn-primary">+Agregar Pelicula</button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
        crossorigin="anonymous"></script>
    <script src="./js/logica.js"></script>
</body>

</html>