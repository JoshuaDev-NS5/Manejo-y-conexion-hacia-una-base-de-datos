const mostrar_cartelera=async ()=>{
    try{
        const respuesta= await fetch('./datos/cartelera.json')
        const datos=await respuesta.json()
        mostrarcartelera(datos)
    }catch(error){
        console.log(`Uff ha ocurrido un error: ${error} ` );
    }
}
mostrar_cartelera()


function mostrarcartelera(cartelera){

    let listado=document.getElementById('Cartelera')
    listado.innerHTML=''
    cartelera.forEach(cartelera => {
        listado.innerHTML +=`
            <div class="col-9 col-md-3 col-lg-2 my-3 mx-5 p-0 peliculas ">
                <img class="w-100" src="${cartelera.imagen}" alt="${cartelera.titulo}">
                <div class="datos pt-2">
                        <h6>Titulo: ${cartelera.titulo}</h6>
                        <h6>Duracion: ${cartelera.duracion}</h6>
                        <h6>Genero: ${cartelera.genero}</h6>
                </div>
            </div>
        `
    });

}