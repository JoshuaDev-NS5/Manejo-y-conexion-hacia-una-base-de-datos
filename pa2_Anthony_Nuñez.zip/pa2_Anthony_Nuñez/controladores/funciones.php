<?php
    function conectar_base_de_datos($host,$name_db,$user,$pasword){
        try{
            $db=new PDO("mysql:host=$host;dbname=$name_db",$user,$pasword);
            return $db;
        }catch (PDOException $error) {
            echo  '<h2 style="color:red;">'.'Ufff ha ocurrido un error: '.$error->getMessage().'</h2>';
        }
    }

    function conectar_a_tabla_movies($bd,$tabla,$datos){
        try{
            $query="INSERT INTO $tabla (titulo, calificacion, premios, fechaCreacion,duracion, genero)
                    VALUES (:titulo, :calificacion, :premios, :fechaCreacion, :duracion, :genero)";
            $stmt=$bd->prepare($query);
            $stmt->execute(
                [  
                    ':titulo'=>$datos['titulo'],
                    ':calificacion'=>$datos['calificacion'],
                    ':premios'=>$datos['premios'],
                    ':fechaCreacion'=>$datos['fechaCreacion'],
                    ':duracion'=>$datos['duracion'],
                    ':genero'=>$datos['genero']

                ]
                );
            /*echo "<h4 style='color:green;'> Película agregada correctamente</h4>";*/
        }catch (PDOException $error){
            echo "<h4 style='color:red;'> Error al guardar los datos: " . $error->getMessage() . "</h4>";
        }
        header('location: index.php');
    }

    //validar registro
    function validadar_datos($datos){
        /*var_dump($datos);
        exit;*/
        $titulo=$datos["titulo"];
        $calificacion=$datos["calificacion"];
        $premios=$datos["premios"];
        $fecha_de_cracion=$datos["fechaCreacion"];
        $duracion=$datos["duracion"];
        $genero=$datos["genero"];
        $errores=[];
        if($titulo === ''){
            $errores['titulo'] = 'El campo titulo no puede estar vacío';
        }
        if($calificacion === ''){
            $errores['calificacion'] = 'El campo calificación no puede estar vacío';
        }
        if($premios===''){
            $errores['premios']='El campo premios esta vacio';
        }
        if($fecha_de_cracion===''){
            $errores['fechaCreacion']='El campo fechaCreacion esta vacio';
        }
        if($duracion===''){
            $errores['duracion']='El campo duracion esta vacio';
        }
        if($genero===''){
            $errores['genero']='El genero duracion esta vacio';
        }
        // Expresiones regulares - regex 
        // método de php. llamado: .test() en JavaScript == preg_match() en PHP

        return $errores;
    }
?>